from flask import Flask, request, render_template
import csv

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat")
def chat():

    message = request.args.get("message", "").lower()

    country = ""
    target_group = ""

    # Detect Country

    if "india" in message:
        country = "india"

    elif "usa" in message or "america" in message:
        country = "usa"

    elif "canada" in message:
        country = "canada"

    elif "uk" in message or "united kingdom" in message:
        country = "uk"

    # Detect User Group

    if "student" in message:
        target_group = "students"

    elif "farmer" in message:
        target_group = "farmers"

    elif "girl" in message:
        target_group = "girls"

    elif "senior" in message:
        target_group = "senior citizens"

    elif "low income" in message:
        target_group = "low income families"

    results = []

    with open("../data/schemes.csv", "r", encoding="utf-8") as file:

        reader = csv.DictReader(file)

        for row in reader:

            if (
                row["country"].strip().lower() == country
                and row["target_group"].strip().lower() == target_group
            ):

                results.append(row)

    return render_template(
        "results.html",
        results=results
    )


if __name__ == "__main__":
    app.run(debug=True)